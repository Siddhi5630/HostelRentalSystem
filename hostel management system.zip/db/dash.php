<?php
$user ='root';
$password ='';
$database ='hostel1';
$servername = 'localhost:3312';

$var_connection=mysqli_connect($servername,$user,$password,$database);
if(!$var_connection)
{
  die('Connect Error:' . mysqli_connect_error());
}


if(isset($_POST['save']))
{
  $email=$_POST['email'];
  $password=$_POST['password'];
  $mobileNO=$_POST['mobileNO'];



$query1="SELECT * from register where email='$email' and password='$password' and mobileNO='$mobileNO' ";
if ($result = mysqli_query($var_connection, $query1))

{
  $count=mysqli_num_rows($result);
  if($count ==1){
  //  echo "Login Successful";
    ?>
    <!DOCTYPE html>
    <html lang="en" dir="ltr">
      <head>
        <meta charset="utf-8">
        <title></title>
      <!--  <link rel="stylesheet" href="css/style.css">-->
        <style>
      /*  div {
          border: 1px solid black;
          background-color: white;
          padding-top: 10px;
          padding-right: 50px;
          padding-bottom: 50px;

        }*/
        </style>

      </head>
      <body>
        <br >
        <br >

        <hr style="height:2px;border-width:0;color:gray;background-color:gray">

      <!--  <hr style="height:2px;border-width:0;color:gray;background-color:gray">

    <h1>Registration successful</h1>-->
  <br >
  <!--  <form action="main.php" method="post">-->
<div class="">
  <!--<h1 style="text-align:center">LOGIN SUCCESSFUL</h1>-->
  <font size="4"
     face="verdana"
     color="white">
       <!--LOGIN SUCCESSFUL
   </font>


 <input class="favorite styled" type="submit" value="CHECK STATUS" align=center  >

</div>
    <hr style="height:2px;border-width:0;color:gray;background-color:gray"> -->
<!--    <hr style="height:2px;border-width:0;color:gray;background-color:gray">
    <br >

          <input type="submit" class="btn btn-primary w-100" name="save" value="Check Status"  />-->
        </form>
        <br>
        <br>

      </body>
    </html>
    <?php


  }
  else
  {
//echo"Incorrect password or email";
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h2>Incorrect password or email</h2>
  </body>
</html>
<?php
  }
  }


  else{
    echo "Error: " . $sql . "" > mysqli_error($var_connection);
  }


 ?>


<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<style type="text/css">
    table{
        /*border: 3px solid white;*/

    }
    tr,th   {border: 1px solid black;   color: black;

    }
    body{
background-color: pink;
    }
    p{
        color: black;
    }
    .content {
      position: fixed;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      color: #f1f1f1;
      width: 100%;
      padding: 20px;
    }+



</style>
<body><br><br>


  <?php
  
    $queryq="select * from tb1_info where mobileNO = '$mobileNO'";
    $res=mysqli_query($var_connection,$queryq);
    if(mysqli_num_rows($res)>0){
    //  echo "mobileNO";
            while($row = mysqli_fetch_assoc($res)){
error_reporting(0);
        echo " <h1><p align="."center".">".$row["fullname"]."<p></h1></th><th><table width="."100%".">
        <tr><th>FULLNAME</th><th>".$row["fullname"]."</th></tr>
        <tr><th>GENDER</th><th>".$row["gender"]."</th></tr>
        <tr><th>ADDRESS</th><th>".$row["address"]."</th></tr>
        <tr><th>PINCODE</th><th>".$row["pincode"]."</th></tr>
        <tr><th>EMAIL</th><th>".$row["email"]."</th></tr>


        <tr><th>MOBILENO</th><th>".$row["mobileNO"]."</th></tr>
        <tr><th>COLLEGE NAME</th><th>".$row["collegename"]."</th></tr>
        <tr><th>YEAR OF STUDY</th><th>".$row["yearofstudy"]."</th></tr></table></th>
        </tr></table>";

}
}
else
{
  echo "error";
    // echo "<script type='text/javascript'>alert('PLAYER NOT FOUND!!');</script>";
    //  header("refresh: 0.01; url=user1st.html");

}


  mysqli_close($var_connection);
}
  ?>
</body></html>

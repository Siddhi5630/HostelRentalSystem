<?php
$user ='root';
$password ='';
$database ='hostel1';
$servername = 'localhost:3312';
$conn=mysqli_connect($servername,$user,$password,$database);

if(!$conn)
{
  die('Connect Error:' . mysqli_connect_error());
}

if(isset($_POST['save']))
{
    $name=$_POST['fullname'];
    $gender=$_POST['gender'];
    $address=$_POST['addresss'];
    $pincode=$_POST['pincode'];
    $email=$_POST['emailid'];
    $mobileNO=$_POST['phoneno'];
    $college=$_POST['collegename'];
    $yearofstudy=$_POST['yearofstudy'];
    $sql_query="INSERT INTO tb1_info(fullname,gender,addresss,pincode,emailid,phoneno,collegename,yearofstudy)VALUES('$name','$gender',' $address','$pincode',' $email',' $mobileNO','$college',' $yearofstudy')";
   // $sql_query="INSERT INTO tb1_info(name,gender,address,pincode,email,phoneno,college,yearofstudy)VALUES('$name','$gender',' $address',' $email','$pincode',' $phoneno','$college',' $yearofstudy')";

    if(mysqli_query($conn,$sql_query))
    {
      //  echo " New details entry inserted successfuly !";

        ?>
        <!DOCTYPE html>
        <html lang="en" dir="ltr">
          <head>
            <meta charset="utf-8">
            <title></title>
            <link rel="stylesheet" href="css/style.css">
            <style>
            div {
              border: 1px solid black;
              background-color: white;
              padding-top: 10px;
              padding-right: 50px;
              padding-bottom: 50px;

          }
            </style>

          </head>
          <body>
            <br >
            <br >

            <hr style="height:2px;border-width:0;color:gray;background-color:gray">

          <!--  <hr style="height:2px;border-width:0;color:gray;background-color:gray">

        <h1>Registration successful</h1>-->
      <br >
      <!--  <form action="dash.php" method="post">-->
    <div class="">
      <h2 style="text-align:center"> New details entry inserted successfuly !</h2>

    <!--  <input class="favorite styled" type="submit" value="CHECK STATUS" align=center  >-->

    </div>
        <hr style="height:2px;border-width:0;color:gray;background-color:gray">
        <br >

            <!--  <input type="submit" class="btn btn-primary w-100" name="save" value="Check Status"  />-->
            </form>
            <br>
            <br>

          </body>
        </html>
        <?php


    }
    else
    {
        echo " error :" . $sql . "" . mysqli_error($conn);
    }

?>
    <!DOCTYPE html>
    <html>
    <head>
        <title></title>
    </head>
    <style type="text/css">
        table{
            /*border: 3px solid white;*/

        }
        tr,th   { border: 1px solid black;   color: black;

        }
        body{
    background-color: pink;
        }
        p{
            color: black;
        }


    </style>
    <body><br><br>


      <?php
      //   $con = mysqli_connect("localhost", "root", "", "cricket",3307) or die(mysqli_error($con));
      //  $mobileNO=$_POST['mobileNO'];
        $queryq="select * from tb1_info where mobileNO = '$mobileNO'";
        $res=mysqli_query($conn,$queryq);
        if(mysqli_num_rows($res)>0){
          //echo "mobileNO";
                if($row = mysqli_fetch_assoc($res)){
                  error_reporting(0);
            echo " <h1><p align="."center".">".$row["fullname"]."<p></h1>
            <table width="."100%"." height="."400px"."><tr><th height="."100%"."></th><th><table width="."100%".">
            <tr><th>FULLNAME</th><th>".$row["fullname"]."</th></tr>
            <tr><th>GENDER</th><th>".$row["gender"]."</th></tr>
            <tr><th>ADDRESS</th><th>".$row["addresss"]."</th></tr>
            <tr><th>PINCODE</th><th>".$row["pincode"]."</th></tr>
            <tr><th>EMAIL</th><th>".$row["emailid"]."</th></tr>


            <tr><th>MOBILENO</th><th>".$row["phoneno"]."</th></tr>
            <tr><th>COLLEGE NAME</th><th>".$row["collegename"]."</th></tr>
            <tr><th>YEAR OF STUDY</th><th>".$row["yearofstudy"]."</th></tr></table></th>
            </tr></table>";

    }
    }
    else
    {
         echo "<script type='text/javascript'>alert('PLAYER NOT FOUND!!');</script>";
        //  header("refresh: 0.01; url=user1st.html");

    }


      mysqli_close($conn);
    }
      ?>
    </body></html>

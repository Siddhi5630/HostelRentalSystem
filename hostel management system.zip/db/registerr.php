
<?php

$user ='root';
$password ='';
$database ='hostel1';
$servername = 'localhost:3312';
$conn=mysqli_connect($servername,$user,$password,$database);

if(!$conn)
{
  die('Connect Error:' . mysqli_connect_error());
}

if(isset($_POST['save']))
{
  $firstname=$_POST['firstname'];
  $lastname=$_POST['lastname'];
  $email=$_POST['email'];
  $mobileNO=$_POST['mobileNO'];
  $password=$_POST['password'];
  $confirmpassword=$_POST['confirmpassword'];

  if($_POST['password'] !== $_POST['confirmpassword'])
  {
    die('Password and Confirm Password should be the same');
  }

/*if (empty($_POST['username']) ||
    empty($_POST['lastname']) ||
    empty($_POST['email']) ||
    empty($_POST['mobileNO']) ||
    empty($_POST['password']) ||
    empty($_POST['confirmpassword']))
{
  die('Please fill all the fields! ');
}

*/


$sql_query ="INSERT INTO register (firstname,lastname,email,mobileNO,password,confirmpassword) values ('$firstname','$lastname','$email','$mobileNO','$password','$confirmpassword')";

if(mysqli_query($conn ,$sql_query))
{

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/style.css">
    <style>
div {
border: 1px solid black;
background-color: lightblue;
padding-top: 50px;
padding-right: 30px;
padding-bottom: 50px;
padding-left: 80px;
}
</style>

<style>
body {
background-image: url('images/qq.jpeg');
background-repeat: no-repeat;
background-attachment: fixed;
background-size: cover;

}
</style>

<style>
.trans {
  -moz-opacity: 0.5;
  -khtml-opacity: 0.5;

}
</style>



  </head>
  <body>
    <br>
    <br>
    <hr style="height:2px;border-width:0;color:gray;background-color:gray">

    <hr style="height:2px;border-width:0;color:gray;background-color:gray">

<!--<h1 align='center' font='algerian'>REGISTRATION SUCCESSFUL</h1>-->
<font size="6"
   face="verdana"
   color="white">
     REGISTRATION SUCCESSFUL
 </font>
<br>
<br>

    <form action="newuserlogin.html" method="post">

      <input type="submit" class="favorite styled" name="save" value="LOGIN PLEASE"  />
      <hr style="height:2px;border-width:0;color:gray;background-color:gray">
      <hr style="height:2px;border-width:0;color:gray;background-color:gray">

      <br><br>

    </form>
    <br>
    <br>

  </body>
</html>
<?php
}

else{
  echo"Error: " . $sql . "" . mysqli_error($conn);
}
mysqli_close($conn);





}
 ?>

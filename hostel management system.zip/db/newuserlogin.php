<?php
$user ='root';
$password ='';
$database ='hostel1';
$servername = 'localhost:3312';

$var_connection=mysqli_connect($servername,$user,$password,$database);
if(!$var_connection)
{
  die('Connect Error:' . mysqli_connect_error());
}


if(isset($_POST['save']))
{
  $email=$_POST['email'];
  $password=$_POST['password'];
$mobileNO=$_POST['mobileNO'];



$query1="SELECT * from register where email='$email' and password='$password' and mobileNO='$mobileNO' ";
if ($result = mysqli_query($var_connection, $query1))

{
  $count=mysqli_num_rows($result);
  if($count ==1){
  //  echo "Login Successful";
    ?>
    <!DOCTYPE html>
    <html lang="en" dir="ltr">
      <head>
        <meta charset="utf-8">
        <title></title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <style>
    div {
    border: 1px solid black;
    background-color: lightblue;
    padding-top: 50px;
    padding-right: 30px;
    padding-bottom: 50px;
    padding-left: 80px;
    }
    </style>

    <style>
    body {
    background-image: url('images/qq.jpeg');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;

    }
    </style>

    <style>
    .trans {
      -moz-opacity: 0.5;
      -khtml-opacity: 0.5;

    }
    </style>

      </head>
      <body>

          <br >
        <br >

        <hr style="height:2px;border-width:0;color:gray;background-color:gray">

        <hr style="height:2px;border-width:0;color:gray;background-color:gray">
    <!--    <h1 style="text-align:center">LOGIN SUCCESSFUL</h1>-->
          <!--<h1 align='center' font='algerian'>LOGIN SUCCESSFUL</h1>-->
          <font size="6"
             face="verdana"
             color="white">
               LOGIN SUCCESSFUL
           </font>

    <!--<h1>Registration successful</h1>-->
  <br >

  <form action="hostel.html" method="post">

  <input class="favorite styled" type="submit" value="CHECK STATUS" align=center  >
    <!--  <input type="button" class="btn btn-primary w-100" name="save" value=""  />-->

    <hr style="height:2px;border-width:0;color:gray;background-color:gray">
    <hr style="height:2px;border-width:0;color:gray;background-color:gray">
    <br >

        </form>
        <br>
        <br>

      </body>
    </html>
  <?php


  }
  else{
echo"Incorrect password or email";

  }
  }

  else{
    echo "Error: " . $sql . "" > mysqli_error($var_connection);
  }

  mysqli_close($var_connection);
}

 ?>

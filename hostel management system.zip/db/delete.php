<?php
$server_name="localhost:3312";
$username="root";
$password="";
$database_name="hostel1";
$conn=mysqli_connect($server_name,$username,$password,$database_name);
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}

$phoneno1 = $_GET['phoneno'];
$delete_query = "delete from tb1_info where phoneno=$phoneno1";
$query = mysqli_query($conn , $delete_query);

include ('admin.php');
 ?>
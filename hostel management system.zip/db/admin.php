<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN AREA</title>
   <link rel="stylesheet" href="css/admin.css">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/bootstrap.css">
   <script src="https://kit.fontawesome.com/6abf88c977.js" crossorigin="anonymous"></script>
   
</head>

<body>
    

    <div class="main-div">
        <h1> </h1>
        <br>
        <h1> ADMIN </h1>
        <h2><centre> List Of Students Enrolled</centre> </h2>

        <div class="center-div">
            <div class="table-responsive" >
                <table>
                    <thead>
                        <tr>
                            
                            <th> FULL NAME </th>
                            <th> GENDER </th>
                            <th> addresss </th>
                            <th> PINCODE </th>
                            <th> EMAIL-ID </th>
                            <th> PHONE_NO </th>
                            <th> COLLEGE NAME </th>
                            <th> YEAR OF STUDY </th>
                            <th colspan="2" >operation</th>
                        </tr>

                    </thead>
                    <tbody>
                        <tr>
                     
                     
                     <?php
$server_name="localhost:3312";
$username="root";
$password="";
$database_name="hostel1";
$conn=mysqli_connect($server_name,$username,$password,$database_name);
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}
else 
    echo "";
$sql = "select * from tb1_info";
$result = mysqli_query($conn,$sql);
$num = mysqli_num_rows($result);
echo " ";
echo "\nTotal Number of students enrolled : ";
echo $num ."<br>" ;
echo "<br>";

while( $row = mysqli_fetch_array($result)){
   
    ?>
    <tr>
        <td><?php echo $row['fullname']; ?></td>
        <td><?php echo $row['gender']; ?></td>
        <td><?php echo $row['addresss']; ?></td>
        <td><?php echo $row['pincode']; ?></td>
        <td><?php echo $row['emailid']; ?></td>
        <td><?php echo $row['phoneno']; ?></td>
        <td><?php echo $row['collegename']; ?></td>
        <td><?php echo $row['yearofstudy']; ?></td>
        <td> <a href="delete.php?phoneno=<?php echo $row['phoneno']; ?>" data-toggle="top" title="DELETE">
        <i class="fa fa-trash" aria-hidden="true"></i></a></td>
        <td><a href="update3.php?phoneno=<?php echo $row['phoneno']; ?>" data-toggle="top" title="UPDATE">
            <i class="fas fa-edit"></a></i>
    </td>

    <?php
}
?>
                       </tr>
                        
                    </tbody>
                <table>

            </div>
        </div>

    </div>

<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</body>

</html>   


<link rel="stylesheet" href="css/admin.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/bootstrap.css">

<?php
$server_name="localhost:3312";
$username="root";
$password="";
$database_name="hostel1";
$conn=mysqli_connect($server_name,$username,$password,$database_name);
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}

$phoneno = $_GET['phoneno'];

$showquery = "select * from tb1_info where phoneno=$phoneno";
$showdata = mysqli_query($conn , $showquery);
$arrdata = mysqli_fetch_array($showdata);

?>

<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update form</title>
</head>
 
<body>
   
    <div class="container vh-100">
 
 
        <div class="row justify-content-center h-90">
          <div class="card w-50 my-auto shadow">
   
            <div class="panel panel-primary">
              <div class="panel-heading text-center">
                <div class="card-header text-center bg-primary text-white">
   
        <h1>Update Form</h1>
    </div>
  </div>
  <div class="panel-body">


    <form action="newupdate.php" method="post">
        <div class="form-group"></div>

        <p>Required fields are followed by *</p>
        <h4>Contact Information</h4>
        <label for="name">Full Name *:</label>
       <input type="text" name="name" id="name" value="<?php echo $arrdata['fullname']; ?>" required>
       <br>
    </div>
    <br>
    <div class="form-group">
        <label for="gender">Gender *:</label>
       
            <div>
                <fieldset>
                <label for="female" class="radio-inline" >
                     <input type="radio" name="gender" id="female" value="<?php echo $arrdata['gender']; ?>" required > Female</label>
                 <label for="male" class="radio-inline">
                     <input type="radio" name="gender" id="male" value="<?php echo $arrdata['gender']; ?>" required> Male</label>
                 <label for="other" class="radio-inline">
                     <input type="radio" name="gender" id="other" value="<?php echo $arrdata['gender']; ?>" required> Other</label>
                    </fieldset>
                    </div>
       
       
                <div>
                </div>
                <br>
       
                <div class="form-group">
                    <label for="addresss">addresss *:</label>
            <input type="text" name = "addresss" value="<?php echo $arrdata['addresss']; ?>">
           
           <br>
        </div>
        <div class="form-group">
            <label for="email">Email :*</label>
            <input type="email" name="email" id="email" value="<?php echo $arrdata['emailid']; ?>" required class="form-control" /><br>
        </div>
        <div class="form-group">
            <label for="pincode">Pincode *:</label>
            <input type="number" name="pincode" id="pincode"  value="<?php echo $arrdata['pincode']; ?>" required class="form-control" /><br>
        </div>
        <div class="form-group">
            <label for="phoneno">Phone Number *: </label>
            <input type="text" name="phoneno" id="phoneno" value="<?php echo $arrdata['phoneno']; ?>" required class="form-control" />
            <br>
    </div>
        <h4>Educational Information</h4>
        <div class="form-group">
            <label for="college">College Name: </label>
            <input type="text" name="college" id="college" value="<?php echo $arrdata['collegename']; ?>"  class="form-control">
            <br>
        </div>
        <p>Year of Study:
            <select name="yearofstudy" id="yearofstudy" value="<?php echo $arrdata['yearofstudy']; ?>">
                   <option value="">---- select year of study ----</option>
                   <option value="fy">First year</option>
                   <option value="sy">Second year</option>
                   <option value="ty">Third year</option>
                   <option value="ffy">Final year</option>
               </select>
        </p>
        <p></p>
        <input type="submit" name="update" value="UPDATE">
    </form>
</div>
<div class="panel-footer text-right">
  <small>&copy; Cummins College</small>
</div> 
</div>
</div>
</div>
</div>
</body>
 </html>



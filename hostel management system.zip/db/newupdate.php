<?php

$server_name="localhost:3312";
$username="root";
$password="";
$database_name="hostel1";
$conn=mysqli_connect($server_name,$username,$password,$database_name);
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}

if(isset($_POST['update'])){

  $phoneno = $_GET['phoneno'];
    echo $phoneno;
    
    $fullname=$_POST['name'];
    $gender=$_POST['gender'];
    $addresss=$_POST['addresss'];
    $pincode=$_POST['pincode'];
    $emailid=$_POST['email'];
    $phoneno=$_POST['phoneno'];
    $collegename=$_POST['college'];
    $yearofstudy=$_POST['yearofstudy'];
    

    $query = "UPDATE tb1_info SET 
    fullname = '$fullname', 
    gender = '$gender',
    addresss = '$addresss',
    pincode = '$pincode', 
    emailid = '$emailid',
    phoneno = '$phoneno',
    collegename = '$collegename',
    yearofstudy = '$yearofstudy'
    WHERE phoneno=$phoneno";
    

    $data = mysqli_query($conn ,$query);

    if($data) {
        header("refresh: 0.01 ;url=admin.php");
        echo "Successfully updated :)";
    }
    else {
        echo"Not updated";
    }
    mysqli_close($conn);
}
 ?>





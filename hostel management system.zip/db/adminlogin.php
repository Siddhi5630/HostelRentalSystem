<?php
$user ='root';
$password ='';
$database ='hostel1';
$servername = 'localhost:3312';

$var_connection=mysqli_connect($servername,$user,$password,$database);
if(!$var_connection)
{
  die('Connect Error:' . mysqli_connect_error());
}


if(isset($_POST['save']))
{
  $email=$_POST['email'];
  $password=$_POST['password'];




$query2="SELECT * from adminregister where email='$email' and password='$password' ";
if ($result = mysqli_query($var_connection, $query2))

{
  $count=mysqli_num_rows($result);
  if($count ==1){
  //  echo "Login Successful";
  ?>
  <!DOCTYPE html>
  <html lang="en" dir="ltr">
    <head>
      <meta charset="utf-8">
      <title></title>
      <link rel="stylesheet" href="css/style.css">

      <style>
div {
  border: 1px solid black;
  background-color: lightblue;
  padding-top: 50px;
  padding-right: 30px;
  padding-bottom: 50px;
  padding-left: 80px;
}
</style>

<style>
body {
background-image: url('images/qq.jpeg');
background-repeat: no-repeat;
background-attachment: fixed;
background-size: cover;

}
</style>

<style>
  .trans {
    -moz-opacity: 0.5;
    -khtml-opacity: 0.5;

  }
</style>


    </head>
    <body>
      <br >
      <br >
      <hr style="height:4px;border-width:0;color:white;background-color:white">

      <hr style="height:4px;border-width:0;color:white;background-color:white">
  <!--    <h1 style="text-align:center" font color="white" >LOGIN SUCCESSFUL</h1>-->
  <br>
      <font size="6"
         face="verdana"
         color="white">
           LOGIN SUCCESSFUL
       </font>
       <br>
       <br>
      <form action="admin.php" method="post">
        <input type="submit" class="favorite styled" name="save" value="Check info of students" margin=500px />
      </form>
  <!--<h1>Registration successful</h1>-->
  <br>

  <hr style="height:4px;border-width:0;color:white;background-color:white">
  <hr style="height:4px;border-width:0;color:white;background-color:white">

  <br >
  <br >

  <!--
      <form action="newuserlogin.html" method="post">
        <input type="submit" class="btn btn-primary w-100" name="save" value="LOGIN PLEASE"  />
      </form>-->
      <br>
      <br>

    </body>
  </html>
  <?php


  }
  else{
echo"Incorrect password or email";

  }
  }

  else{
    echo "Error: " . $sql . "" > mysqli_error($var_connection);
  }



















  mysqli_close($var_connection);
}

 ?>
